# 9.2 > Roboflow Instant 1 [Eval]
https://universe.roboflow.com/yolo-6rl1p/9.2-ikdzb

Provided by a Roboflow user
License: Public Domain

